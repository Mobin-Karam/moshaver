export { ResourcesPage } from "./ResourcesPage";
