import { useState, type ReactNode } from "react";
import { Trash2, X } from "lucide-react";
import { Link } from "react-router-dom";
import type { Exam, PlanTask } from "../../../shared/types/domain";
import { DatePicker } from "../../../shared/ui/date-picker";
import { Button, Field, Input, Select, Textarea } from "../../../shared/ui/ui";
import type { PlanDraft, TaskDraft } from "../model/planner.types";
import { errorMessage, taskTypeLabel, validateTaskDraft } from "../lib/planner-model";

export function PlanForm({
  initial,
  lockDate,
  busy,
  onSubmit,
  onCancel,
}: {
  initial: PlanDraft;
  lockDate: boolean;
  busy: boolean;
  onSubmit: (data: PlanDraft) => void | Promise<void>;
  onCancel: () => void;
}) {
  const [data, setData] = useState(initial);
  const [error, setError] = useState("");
  return (
    <form
      className="grid gap-3"
      onSubmit={(e) => {
        e.preventDefault();
        setError("");
        void Promise.resolve(onSubmit(data)).catch((reason) =>
          setError(errorMessage(reason, "ذخیره برنامه انجام نشد.")),
        );
      }}
    >
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="تاریخ ISO">
          <DatePicker
            required
            disabled={lockDate}
            value={data.planDate}
            onChange={(planDate) => setData({ ...data, planDate })}
          />
        </Field>
        <Field label="عنوان">
          <Input
            value={data.title || ""}
            onChange={(e) => setData({ ...data, title: e.target.value })}
          />
        </Field>
        <Field label="عنوان روز">
          <Input
            value={data.dayLabel || ""}
            onChange={(e) => setData({ ...data, dayLabel: e.target.value })}
          />
        </Field>
        <Field label="تاریخ فارسی">
          <Input
            value={data.persianDate || ""}
            onChange={(e) => setData({ ...data, persianDate: e.target.value })}
          />
        </Field>
        <Field label="شناسه شمسی">
          <Input
            value={data.jalaliId || ""}
            onChange={(e) => setData({ ...data, jalaliId: e.target.value })}
          />
        </Field>
        <Field label="وضعیت">
          <Select
            value={data.published ? "1" : "0"}
            onChange={(e) => setData({ ...data, published: e.target.value === "1" })}
          >
            <option value="0">پیش‌نویس</option>
            <option value="1">منتشر</option>
          </Select>
        </Field>
      </div>
      <Field label="پیام انگیزشی">
        <Textarea
          maxLength={600}
          rows={3}
          value={data.motivationText || ""}
          onChange={(e) => setData({ ...data, motivationText: e.target.value })}
        />
      </Field>
      {error ? (
        <p role="alert" className="rounded-md bg-rose-50 px-3 py-2 text-sm text-rose-700">
          {error}
        </p>
      ) : null}
      <Actions busy={busy} onCancel={onCancel} />
    </form>
  );
}

export function TaskForm({
  initial,
  exams,
  studentId,
  busy,
  onSubmit,
  onCancel,
}: {
  initial: TaskDraft;
  exams: Exam[];
  studentId: string;
  busy: boolean;
  onSubmit: (data: TaskDraft) => void | Promise<void>;
  onCancel: () => void;
}) {
  const [data, setData] = useState(initial);
  const [error, setError] = useState("");
  return (
    <form
      className="grid gap-3"
      onSubmit={(e) => {
        e.preventDefault();
        const validation = validateTaskDraft(data);
        if (validation) {
          setError(validation);
          return;
        }
        setError("");
        void Promise.resolve(onSubmit(data)).catch((reason) =>
          setError(errorMessage(reason, "ذخیره فعالیت انجام نشد.")),
        );
      }}
    >
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="شروع">
          <Input
            required
            type="time"
            value={data.start}
            onChange={(e) => setData({ ...data, start: e.target.value })}
          />
        </Field>
        <Field label="پایان">
          <Input
            required
            type="time"
            value={data.end}
            onChange={(e) => setData({ ...data, end: e.target.value })}
          />
        </Field>
        <Field label="نوع">
          <Select
            value={data.type}
            onChange={(e) =>
              setData({
                ...data,
                type: e.target.value,
                examId: e.target.value === "exam" ? data.examId : "",
              })
            }
          >
            {["study", "review", "test", "class", "prayer", "meal", "break", "exam"].map((x) => (
              <option key={x} value={x}>
                {taskTypeLabel(x)}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="درس">
          <Input
            value={data.subject}
            onChange={(e) => setData({ ...data, subject: e.target.value })}
          />
        </Field>
        <Field label="عنوان">
          <Input value={data.title} onChange={(e) => setData({ ...data, title: e.target.value })} />
        </Field>
        <Field label="صفحات">
          <Input value={data.pages} onChange={(e) => setData({ ...data, pages: e.target.value })} />
        </Field>
        <Field label="تعداد تست">
          <Input
            min={0}
            type="number"
            value={data.testCount}
            onChange={(e) => setData({ ...data, testCount: Number(e.target.value) })}
          />
        </Field>
        {data.type === "exam" ? (
          <div className="grid gap-1">
            <Field label="آزمون مرتبط">
              <Select
                value={data.examId}
                onChange={(e) => setData({ ...data, examId: e.target.value })}
              >
                <option value="">بدون آزمون</option>
                {exams.map((exam) => (
                  <option key={exam.id} value={exam.id}>
                    {exam.persianDate || exam.isoDate} — {exam.title}
                  </option>
                ))}
              </Select>
            </Field>
            {data.examId ? (
              <Link
                className="text-xs font-bold text-brand hover:underline"
                to={`/admin/questions?examId=${encodeURIComponent(data.examId)}&studentId=${encodeURIComponent(studentId)}`}
              >
                بازکردن بانک سؤال این آزمون
              </Link>
            ) : null}
          </div>
        ) : null}
      </div>
      {error ? (
        <p role="alert" className="rounded-md bg-rose-50 px-3 py-2 text-sm text-rose-700">
          {error}
        </p>
      ) : null}
      <Field label="یادداشت">
        <Textarea
          rows={3}
          value={data.note}
          onChange={(e) => setData({ ...data, note: e.target.value })}
        />
      </Field>
      <Actions busy={busy} onCancel={onCancel} />
    </form>
  );
}
export function DateAction({
  initial,
  onSubmit,
  onCancel,
}: {
  initial: string;
  onSubmit: (date: string) => void | Promise<void>;
  onCancel: () => void;
}) {
  const [date, setDate] = useState(initial);
  const [error, setError] = useState("");
  return (
    <form
      className="grid gap-3"
      onSubmit={(e) => {
        e.preventDefault();
        setError("");
        void Promise.resolve(onSubmit(date)).catch((reason) =>
          setError(errorMessage(reason, "کپی برنامه انجام نشد.")),
        );
      }}
    >
      <Field label="تاریخ مقصد">
        <DatePicker required value={date} onChange={setDate} />
      </Field>
      {error ? (
        <p role="alert" className="rounded-md bg-rose-50 px-3 py-2 text-sm text-rose-700">
          {error}
        </p>
      ) : null}
      <Actions busy={false} onCancel={onCancel} />
    </form>
  );
}
export function TaskDrawer({
  title,
  onClose,
  onDelete,
  children,
}: {
  title: string;
  onClose: () => void;
  onDelete?: () => void;
  children: ReactNode;
}) {
  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/45"
      role="presentation"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <aside
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className="absolute bottom-0 left-0 right-0 max-h-[88vh] overflow-auto rounded-t-2xl bg-white p-5 shadow-2xl md:bottom-0 md:right-auto md:top-0 md:w-[460px] md:rounded-none"
      >
        <header className="mb-4 flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-brand">جزئیات فعالیت</span>
            <h3 className="text-lg font-black">{title}</h3>
          </div>
          <div className="flex gap-1">
            {onDelete ? (
              <Button className="h-9 px-2" variant="ghost" onClick={onDelete}>
                <Trash2 size={17} className="text-rose-600" />
              </Button>
            ) : null}
            <Button className="h-9 px-2" variant="ghost" onClick={onClose}>
              <X size={18} />
            </Button>
          </div>
        </header>
        {children}
      </aside>
    </div>
  );
}
function Actions({ busy, onCancel }: { busy: boolean; onCancel: () => void }) {
  return (
    <div className="flex justify-end gap-2">
      <Button type="button" variant="soft" onClick={onCancel}>
        انصراف
      </Button>
      <Button loading={busy}>ذخیره</Button>
    </div>
  );
}
export function toPlanDraft(
  date: string,
  plan?: import("../../../shared/types/domain").Plan,
): PlanDraft {
  return {
    planDate: date,
    title: plan?.title || "",
    dayLabel: plan?.dayLabel || "",
    persianDate: plan?.persianDate || "",
    jalaliId: plan?.jalaliId || "",
    motivationText: plan?.motivationText || "",
    published: plan?.published ?? false,
  };
}
export function toTaskDraft(task?: PlanTask, count = 0): TaskDraft {
  return {
    start: task?.start || "08:00",
    end: task?.end || "09:00",
    type: task?.type || "study",
    subject: task?.subject || "",
    title: task?.title || "",
    pages: task?.pages || "",
    testCount: task?.testCount || 0,
    note: task?.note || "",
    examId: task?.examId || "",
    sortOrder: task?.sortOrder || count + 1,
  };
}
