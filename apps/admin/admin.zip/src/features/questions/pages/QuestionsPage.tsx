import { useDeferredValue, useEffect, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useSearchParams } from "react-router-dom";
import { useStudentSelection } from "../../../shared/hooks/useStudentSelection";
import { useAuth } from "../../auth/hooks/useAuth";
import { useModal } from "../../../shared/ui/modal";
import { notify } from "../../../shared/ui/notifications";
import {
  createExamQuestion,
  deleteExamQuestion,
  getExamQuestions,
  getStudentExams,
  updateQuestion,
} from "../api/questions.api";
import { QuestionEditor } from "../components/QuestionEditor";
import { QuestionsList } from "../components/QuestionsList";
import { QuestionsSelector } from "../components/QuestionsSelector";
import {
  emptyQuestion,
  questionDraft,
  questionError,
  questionMatches,
  questionNumber,
  questionPayload,
} from "../model/question-model";
export function QuestionsPage() {
  const [params, setParams] = useSearchParams();
  const students = useStudentSelection({ clearOnChange: ["examId", "search"] });
  const examId = params.get("examId") || "";
  const search = params.get("search") || "";
  const [editingId, setEditingId] = useState("");
  const [selected, setSelected] = useState<string[]>([]);
  const [submitted, setSubmitted] = useState(false);
  const [bulkDeleting, setBulkDeleting] = useState(false);
  const [form, setForm] = useState(emptyQuestion);
  const qc = useQueryClient();
  const modal = useModal();
  const auth = useAuth();
  const canCreate = auth.can("questions.create");
  const canUpdate = auth.can("questions.update");
  const canDelete = auth.can("questions.delete");
  const deferredSearch = useDeferredValue(search);
  useEffect(() => {
    setEditingId("");
    setSelected([]);
    setForm(emptyQuestion());
    setSubmitted(false);
  }, [students.studentId, examId]);
  const exams = useQuery({
    queryKey: ["exams-all", students.studentId],
    enabled: !!students.studentId,
    queryFn: () => getStudentExams(students.studentId),
  });
  const questions = useQuery({
    queryKey: ["exam-questions", examId],
    enabled: !!examId,
    queryFn: () => getExamQuestions(examId),
  });
  const nextSortOrder =
    Math.max(0, ...(questions.data || []).map((item, index) => questionNumber(item, index + 1))) +
    1;
  const add = useMutation({
    mutationFn: () =>
      editingId
        ? updateQuestion(editingId, questionPayload(form))
        : createExamQuestion(examId, questionPayload(form)),
    onSuccess: () => {
      setForm({
        ...emptyQuestion(),
        sortOrder: nextSortOrder + (editingId ? 0 : 1),
      });
      setEditingId("");
      notify(editingId ? "سؤال ویرایش شد." : "سؤال افزوده شد.");
      setSubmitted(false);
      void qc.invalidateQueries({ queryKey: ["exam-questions", examId] });
      void qc.invalidateQueries({ queryKey: ["exams"] });
    },
    onError: (error) =>
      notify(error instanceof Error ? error.message : "ذخیره سؤال ناموفق بود.", "error"),
  });
  const remove = useMutation({
    mutationFn: (id: string) => deleteExamQuestion(examId, id),
    onSuccess: (_, id) => {
      setSelected((items) => items.filter((x) => x !== id));
      if (editingId === id) {
        setEditingId("");
        setForm(emptyQuestion());
      }
      notify("سؤال حذف شد.");
      void qc.invalidateQueries({ queryKey: ["exam-questions", examId] });
      void qc.invalidateQueries({ queryKey: ["exams"] });
    },
    onError: (error) =>
      notify(error instanceof Error ? error.message : "حذف سؤال ناموفق بود.", "error"),
  });
  const visibleQuestions = useMemo(
    () => (questions.data ?? []).filter((item) => questionMatches(item, deferredSearch)),
    [questions.data, deferredSearch],
  );
  const validationError = questionError(form);
  const selectedExam = exams.data?.find((exam) => exam.id === examId);
  useEffect(() => {
    if (!examId || !exams.isSuccess || selectedExam) return;
    setParams(
      (current) => {
        const next = new URLSearchParams(current);
        next.delete("examId");
        next.delete("search");
        return next;
      },
      { replace: true },
    );
    notify("آزمون انتخاب‌شده متعلق به این دانش‌آموز نیست.", "warning");
  }, [examId, exams.isSuccess, selectedExam, setParams]);
  const setSearch = (value: string) =>
    setParams(
      (current) => {
        const next = new URLSearchParams(current);
        value ? next.set("search", value) : next.delete("search");
        return next;
      },
      { replace: true },
    );
  return (
    <div className="grid gap-5">
      <QuestionsSelector
        students={students.students}
        studentId={students.studentId}
        setStudentId={(studentId) => {
          students.selectStudent(studentId);
        }}
        examId={examId}
        setExamId={(value) => {
          setParams((current) => {
            const next = new URLSearchParams(current);
            value ? next.set("examId", value) : next.delete("examId");
            next.set("studentId", students.studentId);
            next.delete("search");
            return next;
          });
          setSelected([]);
        }}
        exams={exams.data ?? []}
        loading={exams.isLoading}
        error={exams.isError}
        selectedExam={selectedExam}
        questionCount={questions.data?.length || 0}
      />
      <section className="grid min-h-0 gap-4 lg:h-[calc(100vh-15.5rem)] lg:grid-cols-[minmax(330px,400px)_minmax(0,1fr)]">
        {canCreate || canUpdate ? (
          <QuestionEditor
            editingId={editingId}
            form={form}
            setForm={setForm}
            submitted={submitted}
            validationError={validationError}
            busy={add.isPending}
            disabled={!examId}
            nextSortOrder={nextSortOrder}
            onCancel={() => {
              setEditingId("");
              setForm({ ...emptyQuestion(), sortOrder: nextSortOrder });
              setSubmitted(false);
            }}
            onSubmit={() => {
              setSubmitted(true);
              if (!validationError && examId) add.mutate();
            }}
          />
        ) : null}
        <QuestionsList
          examId={examId}
          items={visibleQuestions}
          total={questions.data?.length || 0}
          loading={questions.isLoading}
          error={questions.isError}
          search={search}
          setSearch={setSearch}
          selected={selected}
          setSelected={setSelected}
          bulkBusy={bulkDeleting}
          onBulkDelete={() =>
            void modal
              .confirm({
                title: `حذف ${selected.length} سؤال؟`,
                tone: "danger",
                confirmLabel: "حذف همه",
              })
              .then(async (ok) => {
                if (!ok) return;
                setBulkDeleting(true);
                try {
                  const ids = [...selected];
                  const results = await Promise.allSettled(
                    ids.map((id) => deleteExamQuestion(examId, id)),
                  );
                  const failed = ids.filter((_, i) => results[i]?.status === "rejected");
                  setSelected(failed);
                  if (editingId && !failed.includes(editingId) && ids.includes(editingId)) {
                    setEditingId("");
                    setForm({ ...emptyQuestion(), sortOrder: nextSortOrder });
                  }
                  failed.length
                    ? notify(
                        `${failed.length} سؤال حذف نشد؛ احتمالاً در سابقه آزمون استفاده شده است.`,
                        "warning",
                      )
                    : notify("سؤال‌های انتخاب‌شده حذف شدند.");
                  void qc.invalidateQueries({
                    queryKey: ["exam-questions", examId],
                  });
                  void qc.invalidateQueries({ queryKey: ["exams"] });
                } finally {
                  setBulkDeleting(false);
                }
              })
          }
          onCopy={(q, index) => {
            setEditingId("");
            setForm({ ...questionDraft(q, index), sortOrder: nextSortOrder });
            setSubmitted(false);
          }}
          onEdit={(q, index) => {
            setEditingId(q.id || "");
            setForm(questionDraft(q, index));
          }}
          onDelete={(q) =>
            q.id &&
            void modal
              .confirm({
                title: "حذف سؤال؟",
                description: "این سؤال از آزمون حذف می‌شود.",
                tone: "danger",
                confirmLabel: "حذف",
              })
              .then((ok) => ok && remove.mutate(q.id!))
          }
          onRetry={() => void questions.refetch()}
          canCreate={canCreate}
          canUpdate={canUpdate}
          canDelete={canDelete}
        />
      </section>
    </div>
  );
}
