import { Link } from "react-router-dom";
import type { Exam } from "../../../shared/types/domain";
import { StudentPicker } from "../../../shared/ui/StudentPicker";
import { Button, Card, Field, Select } from "../../../shared/ui/ui";
export function QuestionsSelector({
  students,
  studentId,
  setStudentId,
  examId,
  setExamId,
  exams,
  loading,
  error,
  selectedExam,
  questionCount,
}: {
  students: Parameters<typeof StudentPicker>[0]["students"];
  studentId: string;
  setStudentId: (id: string) => void;
  examId: string;
  setExamId: (id: string) => void;
  exams: Exam[];
  loading: boolean;
  error: boolean;
  selectedExam?: Exam;
  questionCount: number;
}) {
  return (
    <>
      <header className="flex justify-end">
        {examId ? (
          <Link to={`/admin/exams?studentId=${encodeURIComponent(studentId)}`}>
            <Button variant="soft">بازگشت به آزمون‌ها</Button>
          </Link>
        ) : null}
      </header>
      <Card className="sticky top-16 z-10 shadow-sm">
        <div className="grid gap-3 md:grid-cols-2">
          <Field label="دانش‌آموز">
            <StudentPicker students={students} value={studentId} onChange={setStudentId} />
          </Field>
          <Field label="آزمون">
            <Select
              value={examId}
              disabled={!studentId || loading}
              onChange={(e) => setExamId(e.target.value)}
            >
              <option value="">
                {loading
                  ? "در حال دریافت آزمون‌ها…"
                  : error
                    ? "دریافت آزمون‌ها ناموفق بود"
                    : "انتخاب آزمون"}
              </option>
              {exams.map((exam) => (
                <option key={exam.id} value={exam.id}>
                  {exam.title}
                </option>
              ))}
            </Select>
          </Field>
        </div>
        <div className="mt-3 flex flex-wrap items-center gap-2 text-xs">
          <span className="font-bold">{selectedExam?.title || "آزمونی انتخاب نشده"}</span>
          {selectedExam ? (
            <>
              <span className="rounded-full bg-slate-100 px-2 py-1">
                {selectedExam.persianDate || selectedExam.isoDate}
              </span>
              <span className="rounded-full bg-sky-50 px-2 py-1 text-sky-700">
                {questionCount || selectedExam.delivery?.questionCount || 0} سؤال
              </span>
              <span
                className={`rounded-full px-2 py-1 ${selectedExam.published ? "bg-emerald-50 text-emerald-700" : "bg-amber-50 text-amber-700"}`}
              >
                {selectedExam.published ? "منتشر" : "پیش‌نویس"}
              </span>
            </>
          ) : null}
        </div>
        {selectedExam?.published ? (
          <p className="mt-2 rounded-md bg-amber-50 p-2 text-xs text-amber-800">
            این آزمون منتشر است؛ تغییر سؤال‌ها بلافاصله روی نسخه دانش‌آموز اثر می‌گذارد.
          </p>
        ) : null}
      </Card>
    </>
  );
}
