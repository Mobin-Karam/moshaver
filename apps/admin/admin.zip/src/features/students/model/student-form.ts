import type { Student } from "../../../shared/types/domain";
export type StudentForm = {
  name: string;
  username: string;
  password: string;
  grade: string;
  major: string;
  targetUniversity: string;
  targetField: string;
  targetRank: string;
  dailyCapacity: string;
};
export function emptyStudentForm(): StudentForm {
  return {
    name: "",
    username: "",
    password: "",
    grade: "",
    major: "",
    targetUniversity: "",
    targetField: "",
    targetRank: "",
    dailyCapacity: "",
  };
}
export function studentToForm(student: Student): StudentForm {
  return {
    name: student.name || "",
    username: student.user?.username || student.username || "",
    password: "",
    grade: student.grade || "",
    major: student.major || "",
    targetUniversity: student.targetUniversity || "",
    targetField: student.targetField || student.target_major || "",
    targetRank: student.targetRank || student.rank_goal || "",
    dailyCapacity: student.dailyCapacity || student.daily_capacity || "",
  };
}
export function studentPayload(form: StudentForm, includePassword: boolean) {
  return {
    name: form.name.trim(),
    username: form.username.trim(),
    ...(includePassword ? { password: form.password.trim() } : {}),
    grade: form.grade.trim(),
    major: form.major.trim(),
    targetUniversity: form.targetUniversity.trim(),
    targetField: form.targetField.trim(),
    targetRank: form.targetRank.trim(),
    dailyCapacity: form.dailyCapacity.trim(),
  };
}
export function countData(value: unknown) {
  if (Array.isArray(value)) return value.length;
  if (value && typeof value === "object") return Object.keys(value).length;
  return 0;
}
