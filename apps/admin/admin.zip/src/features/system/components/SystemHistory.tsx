import { History, RotateCcw } from "lucide-react";
import { Button, Card, EmptyState } from "../../../shared/ui/ui";
import type { HistoryRow } from "../model/system.types";
export function SystemHistory({
  title,
  rows = [],
  loading,
  error,
  onRetry,
}: {
  title: string;
  rows?: HistoryRow[];
  loading?: boolean;
  error?: boolean;
  onRetry?: () => void;
}) {
  return (
    <Card className="min-h-72 p-5 sm:p-6">
      <div className="mb-3 flex items-center justify-between gap-2">
        <h3 className="flex items-center gap-2 font-bold">
          <History size={17} />
          {title}
        </h3>
        <span className="rounded-full bg-slate-100 px-2 py-1 text-[11px] text-slate-600">
          {rows.length.toLocaleString("fa-IR")} مورد
        </span>
      </div>
      {loading ? (
        <div className="grid gap-2" aria-label="در حال دریافت تاریخچه">
          {[1, 2, 3].map((item) => (
            <div key={item} className="h-14 animate-pulse rounded-md bg-slate-100" />
          ))}
        </div>
      ) : error ? (
        <EmptyState
          title="دریافت تاریخچه ناموفق بود."
          action={
            <Button variant="soft" onClick={onRetry}>
              <RotateCcw size={14} />
              تلاش دوباره
            </Button>
          }
        />
      ) : rows.length ? (
        <div className="grid max-h-80 gap-2 overflow-auto overscroll-contain">
          {rows.map((row, index) => (
            <article key={String(row.id || index)} className="rounded-lg border p-3 text-sm">
              <div className="flex items-start justify-between gap-2">
                <strong>
                  {String(row.app || row.action || row.type || row.schemaVersion || "رکورد")}
                </strong>
                <time className="shrink-0 text-[10px] text-slate-400">
                  {String(row.createdAt || row.updatedAt || row.created_at || row.updated_at || "")}
                </time>
              </div>
              <p className="mt-1 break-words text-xs text-slate-500">
                {String(row.version || row.notes || row.message || row.entity || row.result || "")}
              </p>
            </article>
          ))}
        </div>
      ) : (
        <EmptyState title="سابقه‌ای وجود ندارد." />
      )}
    </Card>
  );
}
