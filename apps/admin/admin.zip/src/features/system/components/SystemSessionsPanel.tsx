import { ArrowLeft, MonitorSmartphone } from "lucide-react";
import { Link } from "react-router-dom";
import { Badge, Card, EmptyState } from "../../../shared/ui/ui";
import type { Session } from "../model/system.types";
export function SystemSessionsPanel({
  sessions = [],
  loading,
}: {
  sessions?: Session[];
  loading?: boolean;
}) {
  return (
    <Card className="h-full">
      <div className="mb-3 flex items-start justify-between gap-2">
        <div className="flex items-start gap-3">
          <span className="grid size-10 place-items-center rounded-lg bg-indigo-50 text-brand">
            <MonitorSmartphone size={20} />
          </span>
          <div>
            <h3 className="font-bold">وضعیت نشست‌ها</h3>
            <p className="text-xs text-slate-500">مرور سریع دستگاه‌های متصل</p>
          </div>
        </div>
        <Badge>{sessions.length.toLocaleString("fa-IR")} فعال</Badge>
      </div>
      {loading ? (
        <div className="h-20 animate-pulse rounded-lg bg-slate-100" />
      ) : sessions.length ? (
        <div className="grid gap-2">
          {sessions.slice(0, 3).map((session) => (
            <div
              key={session.id}
              className="flex items-center justify-between gap-2 rounded-lg border p-2.5 text-sm"
            >
              <span className="min-w-0 truncate">
                {session.current ? "این دستگاه" : session.userAgent || "دستگاه فعال"}
              </span>
              <Badge tone={session.current ? "green" : "neutral"}>
                {session.current ? "فعلی" : session.ipAddress || "فعال"}
              </Badge>
            </div>
          ))}
        </div>
      ) : (
        <EmptyState title="نشستی پیدا نشد." />
      )}
      <Link
        className="mt-3 inline-flex items-center gap-1 text-xs font-bold text-brand"
        to="/admin/settings"
      >
        <span>مدیریت و بستن نشست‌ها</span>
        <ArrowLeft size={14} />
      </Link>
    </Card>
  );
}
