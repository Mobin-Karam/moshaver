import { Rocket } from "lucide-react";
import { Button, Card, Field, Input, Select, Textarea } from "../../../shared/ui/ui";
import type { ReleaseDraft } from "../model/system.types";
export function ReleasePanel({
  release,
  setRelease,
  busy,
  onSubmit,
}: {
  release: ReleaseDraft;
  setRelease: (value: ReleaseDraft) => void;
  busy: boolean;
  onSubmit: () => void;
}) {
  const validVersion = /^v?\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/.test(release.version.trim());
  return (
    <Card className="p-5 sm:p-6">
      <div className="mb-4 flex items-start gap-3">
        <span className="grid size-10 place-items-center rounded-lg bg-violet-50 text-violet-700">
          <Rocket size={20} />
        </span>
        <div>
          <h3 className="font-bold">ثبت انتشار برنامه</h3>
          <p className="text-xs text-slate-500">
            نسخه قابل رهگیری همراه با توضیح کوتاه تغییرات ثبت کنید.
          </p>
        </div>
      </div>
      <div className="grid gap-3 md:grid-cols-[180px_180px_1fr_auto]">
        <Field label="برنامه">
          <Select
            value={release.app}
            onChange={(event) => setRelease({ ...release, app: event.target.value })}
          >
            <option value="admin">پنل مدیریت</option>
            <option value="student">برنامه دانش‌آموز</option>
            <option value="backend">بک‌اند</option>
          </Select>
        </Field>
        <Field label="نسخه">
          <Input
            dir="ltr"
            placeholder="2.1.0"
            value={release.version}
            onChange={(event) => setRelease({ ...release, version: event.target.value.trim() })}
          />
        </Field>
        <Field label="یادداشت انتشار">
          <Textarea
            maxLength={2000}
            rows={1}
            placeholder="مهم‌ترین تغییرات این نسخه…"
            value={release.notes}
            onChange={(event) => setRelease({ ...release, notes: event.target.value })}
          />
        </Field>
        <Button
          loading={busy}
          className="md:mt-6"
          disabled={!validVersion || busy}
          onClick={onSubmit}
        >
          ثبت انتشار
        </Button>
      </div>
      {release.version && !validVersion ? (
        <p className="mt-2 text-xs text-rose-600" role="alert">
          نسخه را مانند 2.1.0 یا 2.1.0-beta.1 وارد کنید.
        </p>
      ) : null}
    </Card>
  );
}
