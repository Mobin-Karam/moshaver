import { api } from "../../../shared/api/api";
import {
  normalizeAdminNotification,
  type NotificationPage,
  type PushPreferences,
  type PushStatus,
} from "../model/notification-model";
import type {
  AdvisorInbox,
  RecoveryActionInput,
  TaskIssueActionInput,
} from "../model/notification.types";

export async function getNotificationsPage(cursor?: string) {
  const page = await api.get<NotificationPage>(
    `/notifications?limit=20${cursor ? `&cursor=${encodeURIComponent(cursor)}` : ""}`,
  );
  return { ...page, items: page.items.map(normalizeAdminNotification) };
}

export function markNotificationRead(id: string) {
  return api.put(`/notifications/${encodeURIComponent(id)}/read`, {});
}

export function markAllNotificationsRead() {
  return api.put("/notifications/read-all", {});
}

export function getAdvisorInbox(studentId: string) {
  return api.get<AdvisorInbox>(`/students/${encodeURIComponent(studentId)}/advisor-inbox`);
}

export function updateRecoveryRequest(input: RecoveryActionInput) {
  const { id, ...body } = input;
  return api.patch<{ id: string; status: string }>(
    `/recovery-requests/${encodeURIComponent(id)}`,
    body,
  );
}

export function updateTaskIssue(input: TaskIssueActionInput) {
  const { id, ...body } = input;
  return api.patch<{ id: string; status: string }>(
    `/students/task-issues/${encodeURIComponent(id)}`,
    body,
  );
}

export function getPushStatusRemote(endpoint?: string) {
  return api.get<Omit<PushStatus, "supported" | "permission">>(
    `/push/status${endpoint ? `?endpoint=${encodeURIComponent(endpoint)}` : ""}`,
  );
}

export function getPushConfig() {
  return api.get<{
    supported: boolean;
    vapidPublicKey: string;
  }>("/push/config");
}

export function registerPushSubscription(subscription: PushSubscriptionJSON) {
  return api.post("/push/subscriptions", subscription);
}

export function deletePushSubscription(endpoint: string) {
  return api.delete(`/push/subscriptions?endpoint=${encodeURIComponent(endpoint)}`);
}

export function updatePushPreferences(preferences: PushPreferences) {
  return api.put("/push/preferences", preferences);
}

export function sendTestPush() {
  return api.post("/push/test", {});
}
