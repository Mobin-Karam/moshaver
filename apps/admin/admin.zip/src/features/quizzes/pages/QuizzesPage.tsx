import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useSearchParams } from "react-router-dom";
import { useModal } from "../../../shared/ui/modal";
import { notify } from "../../../shared/ui/notifications";
import { useAuth } from "../../auth/hooks/useAuth";
import {
  emptyQuestion,
  questionDraft,
  questionError,
  questionMatches,
} from "../../questions/question-model";
import {
  createQuiz,
  createQuizQuestion,
  deleteQuizQuestion,
  getQuizQuestions,
  getQuizzes,
  updateQuiz,
  updateQuizQuestion,
} from "../api/quizzes.api";
import { QuizEditor } from "../components/QuizEditor";
import { QuizQuestionEditor } from "../components/QuizQuestionEditor";
import { QuizQuestionsList } from "../components/QuizQuestionsList";
import { QuizSidebar } from "../components/QuizSidebar";
import type { QuizDraft } from "../model/quiz.types";
export function QuizzesPage() {
  const qc = useQueryClient();
  const [params, setParams] = useSearchParams();
  const [quizId, setQuizIdState] = useState(params.get("quizId") || "");
  const [editingQuestionId, setEditingQuestionId] = useState("");
  const [search, setSearch] = useState(params.get("question") || "");
  const [quizSearch, setQuizSearch] = useState(params.get("q") || "");
  const [status, setStatus] = useState(params.get("status") || "all");
  const [quiz, setQuiz] = useState<QuizDraft>({
    title: "",
    subject: "",
    durationMinutes: 20,
  });
  const [question, setQuestion] = useState(emptyQuestion);
  const modal = useModal();
  const auth = useAuth();
  const canCreate = auth.can("quizzes.create");
  const canUpdate = auth.can("quizzes.update");
  const canManageQuestions = auth.can("quiz_questions.manage");
  const quizzes = useQuery({ queryKey: ["quizzes"], queryFn: getQuizzes });
  const questions = useQuery({
    queryKey: ["quiz-questions", quizId],
    enabled: !!quizId,
    queryFn: () => getQuizQuestions(quizId),
  });
  const selected = quizzes.data?.find((item) => item.id === quizId);
  const visibleQuizzes = (quizzes.data || []).filter(
    (item) =>
      `${item.title} ${item.subject || ""} ${item.exam_title || ""}`
        .toLocaleLowerCase("fa")
        .includes(quizSearch.trim().toLocaleLowerCase("fa")) &&
      (status === "all" || (status === "active" ? !!item.active : !item.active)),
  );
  function setQuizId(value: string) {
    setQuizIdState(value);
    setParams(
      (current) => {
        const next = new URLSearchParams(current);
        value ? next.set("quizId", value) : next.delete("quizId");
        return next;
      },
      { replace: true },
    );
  }
  function syncFilter(key: "q" | "status" | "question", value: string, fallback = "") {
    setParams(
      (current) => {
        const next = new URLSearchParams(current);
        value && value !== fallback ? next.set(key, value) : next.delete(key);
        return next;
      },
      { replace: true },
    );
  }
  useEffect(() => {
    if (!quizId && quizzes.data?.[0]) setQuizId(quizzes.data[0].id);
  }, [quizId, quizzes.data]);
  useEffect(() => {
    if (quizId && quizzes.isSuccess && !selected) {
      setQuizId("");
      notify("آزمونک انتخاب‌شده دیگر وجود ندارد.", "warning");
    }
  }, [quizId, quizzes.isSuccess, selected]);
  useEffect(() => {
    if (selected)
      setQuiz({
        title: selected.title,
        subject: selected.subject || "",
        durationMinutes: selected.duration_minutes || 20,
      });
  }, [selected?.id]);
  const save = useMutation({
    mutationFn: () => (quizId ? updateQuiz(quizId, quiz) : createQuiz(quiz)),
    onSuccess: (value) => {
      qc.invalidateQueries({ queryKey: ["quizzes"] });
      notify(quizId ? "آزمونک به‌روز شد." : "آزمونک ساخته شد.");
      if (value && typeof value === "object" && "id" in value) setQuizId(String(value.id));
    },
    onError: (error) =>
      notify(error instanceof Error ? error.message : "ذخیره آزمونک ناموفق بود.", "error"),
  });
  const toggle = useMutation({
    mutationFn: () => updateQuiz(quizId, { active: !selected?.active }),
    onSuccess: () => {
      notify(selected?.active ? "آزمونک غیرفعال شد." : "آزمونک فعال شد.");
      void qc.invalidateQueries({ queryKey: ["quizzes"] });
    },
    onError: (error) =>
      notify(error instanceof Error ? error.message : "تغییر وضعیت آزمونک ناموفق بود.", "error"),
  });
  const add = useMutation({
    mutationFn: () =>
      editingQuestionId
        ? updateQuizQuestion(editingQuestionId, question)
        : createQuizQuestion(quizId, question),
    onSuccess: () => {
      notify(editingQuestionId ? "سؤال آزمونک ویرایش شد." : "سؤال آزمونک افزوده شد.");
      setQuestion(emptyQuestion());
      setEditingQuestionId("");
      qc.invalidateQueries({ queryKey: ["quiz-questions", quizId] });
    },
    onError: (error) =>
      notify(error instanceof Error ? error.message : "ذخیره سؤال ناموفق بود.", "error"),
  });
  const visibleQuestions = (questions.data ?? []).filter((item) => questionMatches(item, search));
  const validationError = questionError(question);
  const remove = useMutation({
    mutationFn: deleteQuizQuestion,
    onSuccess: () => {
      notify("سؤال حذف شد.");
      void qc.invalidateQueries({ queryKey: ["quiz-questions", quizId] });
    },
    onError: (error) =>
      notify(error instanceof Error ? error.message : "حذف سؤال ناموفق بود.", "error"),
  });
  return (
    <div className="grid gap-5">
      <section className="grid gap-4 lg:grid-cols-[300px_1fr]">
        <QuizSidebar
          quizzes={visibleQuizzes}
          loading={quizzes.isLoading}
          error={quizzes.isError}
          selectedId={quizId}
          search={quizSearch}
          status={status}
          onNew={() => {
            setQuizId("");
            setQuiz({ title: "", subject: "", durationMinutes: 20 });
          }}
          onSearch={(v) => {
            setQuizSearch(v);
            syncFilter("q", v);
          }}
          onStatus={(v) => {
            setStatus(v);
            syncFilter("status", v, "all");
          }}
          onSelect={setQuizId}
          onRetry={() => void quizzes.refetch()}
          onClear={() => {
            setQuizSearch("");
            setStatus("all");
            syncFilter("q", "");
            syncFilter("status", "all", "all");
          }}
          canCreate={canCreate}
        />
        <div className="grid gap-4">
          {(quizId && canUpdate) || (!quizId && canCreate) ? (
            <QuizEditor
              quiz={quiz}
              setQuiz={setQuiz}
              selected={selected}
              busy={save.isPending}
              onSave={() => save.mutate()}
              onToggle={() =>
                void modal
                  .confirm({
                    title: selected?.active ? "غیرفعال‌کردن آزمونک؟" : "فعال‌کردن آزمونک؟",
                    description: selected?.active
                      ? "دانش‌آموزان دیگر به این آزمونک دسترسی نخواهند داشت."
                      : "آزمونک دوباره برای دانش‌آموزان قابل استفاده می‌شود.",
                    confirmLabel: selected?.active ? "غیرفعال کن" : "فعال کن",
                  })
                  .then((ok) => ok && toggle.mutate())
              }
            />
          ) : null}
          {quizId ? (
            <section className="grid gap-4 xl:grid-cols-[380px_1fr]">
              {canManageQuestions ? (
                <QuizQuestionEditor
                  editingId={editingQuestionId}
                  question={question}
                  setQuestion={setQuestion}
                  error={validationError}
                  busy={add.isPending}
                  onCancel={() => {
                    setEditingQuestionId("");
                    setQuestion(emptyQuestion());
                  }}
                  onSave={() => add.mutate()}
                />
              ) : null}
              <QuizQuestionsList
                items={visibleQuestions}
                loading={questions.isLoading}
                error={questions.isError}
                search={search}
                onSearch={(v) => {
                  setSearch(v);
                  syncFilter("question", v);
                }}
                onRetry={() => void questions.refetch()}
                onEdit={(item, index) => {
                  setEditingQuestionId(item.id);
                  setQuestion(questionDraft(item, index));
                }}
                onDelete={(item) =>
                  void modal
                    .confirm({
                      title: "حذف سؤال آزمونک؟",
                      description: "این سؤال برای همیشه از آزمونک حذف می‌شود.",
                      tone: "danger",
                      confirmLabel: "حذف",
                    })
                    .then((ok) => ok && remove.mutate(item.id))
                }
                canManage={canManageQuestions}
              />
            </section>
          ) : null}
        </div>
      </section>
    </div>
  );
}
