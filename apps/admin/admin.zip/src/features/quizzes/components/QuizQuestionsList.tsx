import { CheckCircle2, Pencil, Search } from "lucide-react";
import { Badge, Button, Card, EmptyState, Input } from "../../../shared/ui/ui";
import type { QuizQuestion } from "../model/quiz.types";
export function QuizQuestionsList({
  items,
  loading,
  error,
  search,
  onSearch,
  onRetry,
  onEdit,
  onDelete,
  canManage,
}: {
  items: QuizQuestion[];
  loading: boolean;
  error: boolean;
  search: string;
  onSearch: (v: string) => void;
  onRetry: () => void;
  onEdit: (q: QuizQuestion, i: number) => void;
  onDelete: (q: QuizQuestion) => void;
  canManage: boolean;
}) {
  return (
    <Card>
      <div className="mb-3 flex items-center justify-between">
        <h3 className="font-bold">سؤال‌ها</h3>
        <Badge tone="blue">{items.length} سؤال</Badge>
      </div>
      <div className="relative mb-3">
        <Search className="absolute right-3 top-2.5 text-slate-400" size={16} />
        <Input
          className="pr-9"
          type="search"
          placeholder="جست‌وجوی سؤال…"
          value={search}
          onChange={(e) => onSearch(e.target.value)}
        />
      </div>
      {loading ? (
        <div className="grid gap-2">
          {[1, 2, 3].map((x) => (
            <div key={x} className="h-20 animate-pulse rounded-md bg-slate-100" />
          ))}
        </div>
      ) : error ? (
        <EmptyState
          title="دریافت سؤال‌ها ناموفق بود."
          action={
            <Button variant="soft" onClick={onRetry}>
              تلاش دوباره
            </Button>
          }
        />
      ) : items.length ? (
        <div className="grid max-h-[calc(100dvh-25rem)] gap-2 overflow-y-auto pl-1">
          {items.map((item, index) => (
            <article key={item.id} className="rounded-md border p-3">
              <div className="flex justify-between">
                <strong>سؤال {index + 1}</strong>
                {canManage ? (
                  <div className="flex gap-1">
                    <Button
                      className="h-8 px-2"
                      variant="ghost"
                      onClick={() => onEdit(item, index)}
                    >
                      <Pencil size={14} />
                    </Button>
                    <Button variant="danger" className="h-8 px-2" onClick={() => onDelete(item)}>
                      حذف
                    </Button>
                  </div>
                ) : null}
              </div>
              <p className="mt-2 text-sm">{item.question_text || item.question}</p>
              <span className="mt-2 flex items-center gap-1 text-xs text-emerald-700">
                <CheckCircle2 size={14} />
                پاسخ {item.correct_option}
              </span>
            </article>
          ))}
        </div>
      ) : (
        <EmptyState title="سؤالی ثبت نشده است." />
      )}
    </Card>
  );
}
