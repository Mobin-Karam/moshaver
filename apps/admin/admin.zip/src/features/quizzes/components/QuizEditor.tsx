import { Power, Save } from "lucide-react";
import { Button, Card, Field, Input } from "../../../shared/ui/ui";
import type { Quiz, QuizDraft } from "../model/quiz.types";
export function QuizEditor({
  quiz,
  setQuiz,
  selected,
  busy,
  onSave,
  onToggle,
}: {
  quiz: QuizDraft;
  setQuiz: (q: QuizDraft) => void;
  selected?: Quiz;
  busy: boolean;
  onSave: () => void;
  onToggle: () => void;
}) {
  return (
    <Card>
      <div className="grid gap-3 md:grid-cols-3">
        <Field label="عنوان">
          <Input value={quiz.title} onChange={(e) => setQuiz({ ...quiz, title: e.target.value })} />
        </Field>
        <Field label="درس">
          <Input
            value={quiz.subject}
            onChange={(e) => setQuiz({ ...quiz, subject: e.target.value })}
          />
        </Field>
        <Field label="مدت (دقیقه)">
          <Input
            type="number"
            value={quiz.durationMinutes}
            onChange={(e) => setQuiz({ ...quiz, durationMinutes: Number(e.target.value) })}
          />
        </Field>
      </div>
      <div className="mt-3 flex gap-2">
        <Button
          loading={busy}
          disabled={
            !quiz.title.trim() || quiz.durationMinutes < 1 || quiz.durationMinutes > 360 || busy
          }
          onClick={onSave}
        >
          <Save size={16} />
          ذخیره
        </Button>
        {selected ? (
          <Button variant="soft" onClick={onToggle}>
            <Power size={16} />
            {selected.active ? "غیرفعال" : "فعال"}
          </Button>
        ) : null}
      </div>
    </Card>
  );
}
