import { RotateCcw, Search } from "lucide-react";
import { Badge, Button, Card, EmptyState, Input, Select } from "../../../shared/ui/ui";
import type { Quiz } from "../model/quiz.types";
export function QuizSidebar({
  quizzes,
  loading,
  error,
  selectedId,
  search,
  status,
  onNew,
  onSearch,
  onStatus,
  onSelect,
  onRetry,
  onClear,
  canCreate,
}: {
  quizzes: Quiz[];
  loading: boolean;
  error: boolean;
  selectedId: string;
  search: string;
  status: string;
  onNew: () => void;
  onSearch: (v: string) => void;
  onStatus: (v: string) => void;
  onSelect: (id: string) => void;
  onRetry: () => void;
  onClear: () => void;
  canCreate: boolean;
}) {
  return (
    <Card className="self-start lg:sticky lg:top-20">
      {canCreate ? (
        <Button className="mb-3 w-full" variant="soft" onClick={onNew}>
          آزمونک جدید
        </Button>
      ) : null}
      <div className="mb-3 grid gap-2">
        <div className="relative">
          <Search className="absolute right-3 top-2.5 text-slate-400" size={16} />
          <Input
            className="pr-9"
            type="search"
            placeholder="جستجوی آزمونک…"
            value={search}
            onChange={(e) => onSearch(e.target.value)}
          />
        </div>
        <Select value={status} onChange={(e) => onStatus(e.target.value)}>
          <option value="all">همه وضعیت‌ها</option>
          <option value="active">فعال</option>
          <option value="inactive">غیرفعال</option>
        </Select>
      </div>
      {loading ? (
        <div className="grid gap-2">
          {[1, 2, 3].map((x) => (
            <div key={x} className="h-16 animate-pulse rounded-md bg-slate-100" />
          ))}
        </div>
      ) : error ? (
        <EmptyState
          title="دریافت آزمونک‌ها ناموفق بود."
          action={
            <Button variant="soft" onClick={onRetry}>
              تلاش دوباره
            </Button>
          }
        />
      ) : quizzes.length ? (
        <div className="grid max-h-[calc(100dvh-21rem)] gap-2 overflow-y-auto">
          {quizzes.map((item) => (
            <button
              key={item.id}
              className={`rounded-md border p-3 text-right ${selectedId === item.id ? "border-brand bg-indigo-50" : ""}`}
              onClick={() => onSelect(item.id)}
            >
              <strong>{item.title}</strong>
              <span className="mt-1 flex justify-between text-xs text-slate-500">
                <span>{item.subject || "بدون درس"}</span>
                <Badge tone={item.active ? "green" : "neutral"}>
                  {item.active ? "فعال" : "غیرفعال"}
                </Badge>
              </span>
              <span className="mt-1 block text-xs text-slate-400">
                {item.question_count || 0} سؤال
                {item.exam_title ? ` • ${item.exam_title}` : ""}
              </span>
            </button>
          ))}
        </div>
      ) : (
        <EmptyState
          title={
            search || status !== "all" ? "آزمونکی با این فیلتر پیدا نشد." : "آزمونکی ثبت نشده است."
          }
          action={
            search || status !== "all" ? (
              <Button variant="ghost" onClick={onClear}>
                <RotateCcw size={15} /> پاک‌کردن فیلترها
              </Button>
            ) : undefined
          }
        />
      )}
    </Card>
  );
}
