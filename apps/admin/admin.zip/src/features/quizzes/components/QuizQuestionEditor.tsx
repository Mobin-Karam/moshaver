import { Button, Card, Field, Input, Select, Textarea } from "../../../shared/ui/ui";
import type { QuestionDraft } from "../../questions/question-model";
export function QuizQuestionEditor({
  editingId,
  question,
  setQuestion,
  error,
  busy,
  onCancel,
  onSave,
}: {
  editingId: string;
  question: QuestionDraft;
  setQuestion: (q: QuestionDraft) => void;
  error: string;
  busy: boolean;
  onCancel: () => void;
  onSave: () => void;
}) {
  return (
    <Card>
      <div className="mb-3 flex items-center justify-between">
        <h3 className="font-bold">{editingId ? "ویرایش سؤال" : "سؤال جدید"}</h3>
        {editingId ? (
          <Button className="h-8" variant="ghost" onClick={onCancel}>
            انصراف
          </Button>
        ) : null}
      </div>
      <div className="grid gap-2">
        <Field label="صورت سؤال">
          <Textarea
            value={question.question}
            onChange={(e) => setQuestion({ ...question, question: e.target.value })}
          />
        </Field>
        {question.options.map((value, index) => (
          <Field key={index} label={`گزینه ${index + 1}`}>
            <Input
              value={value}
              onChange={(e) =>
                setQuestion({
                  ...question,
                  options: question.options.map((item, i) => (i === index ? e.target.value : item)),
                })
              }
            />
          </Field>
        ))}
        <Field label="پاسخ">
          <Select
            value={question.correctOption}
            onChange={(e) => setQuestion({ ...question, correctOption: e.target.value })}
          >
            {["a", "b", "c", "d"].map((key, index) => (
              <option key={key} value={key}>
                گزینه {index + 1}
              </option>
            ))}
          </Select>
        </Field>
        <Button loading={busy} disabled={!!error || busy} onClick={onSave}>
          {editingId ? "ذخیره تغییرات" : "افزودن سؤال"}
        </Button>
      </div>
    </Card>
  );
}
