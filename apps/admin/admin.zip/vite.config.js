var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
import http from "node:http";
import https from "node:https";
import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";
var backendTargets = {
    local: "http://localhost:4000",
    remote: "https://api.mahakaram.ir",
};
function selectedBackend(cookieHeader) {
    if (cookieHeader === void 0) { cookieHeader = ""; }
    var match = cookieHeader.match(/(?:^|;\s*)moshaver_admin_backend=(local|remote)(?:;|$)/);
    return (match === null || match === void 0 ? void 0 : match[1]) === "remote" ? "remote" : "local";
}
function devBackendProxy() {
    return {
        name: "dev-backend-proxy",
        configureServer: function (server) {
            server.middlewares.use("/api", function (req, res, next) {
                var target = backendTargets[selectedBackend(req.headers.cookie)];
                var mountedUrl = req.url || "";
                var originalUrl = req.originalUrl;
                var requestPath = (originalUrl === null || originalUrl === void 0 ? void 0 : originalUrl.startsWith("/api/"))
                    ? originalUrl
                    : "/api".concat(mountedUrl.startsWith("/") ? mountedUrl : "/".concat(mountedUrl));
                if (!/^\/api\/v[12](?:\/|$)/.test(requestPath)) {
                    next();
                    return;
                }
                var path = requestPath;
                var upstreamUrl = new URL(path, target);
                var client = upstreamUrl.protocol === "https:" ? https : http;
                var proxyReq = client.request(upstreamUrl, {
                    method: req.method,
                    headers: __assign(__assign({}, req.headers), { host: upstreamUrl.host }),
                }, function (proxyRes) {
                    res.writeHead(proxyRes.statusCode || 502, proxyRes.headers);
                    proxyRes.pipe(res);
                });
                proxyReq.on("error", function () {
                    if (res.headersSent)
                        return;
                    res.statusCode = 502;
                    res.setHeader("Content-Type", "application/json; charset=utf-8");
                    res.end(JSON.stringify({
                        ok: false,
                        error: { code: "PROXY_ERROR", message: "Backend proxy error" },
                    }));
                });
                req.pipe(proxyReq);
            });
        },
    };
}
export default defineConfig({
    plugins: [devBackendProxy(), react()],
    build: {
        rollupOptions: {
            output: {
                manualChunks: function (id) {
                    if (!id.includes("node_modules"))
                        return undefined;
                    if (/node_modules\/(react|react-dom|scheduler)\//.test(id))
                        return "react";
                    if (id.includes("node_modules/react-router"))
                        return "router";
                    if (id.includes("node_modules/@tanstack/"))
                        return "query";
                    if (/node_modules\/(lucide-react|react-multi-date-picker|@persian-tools)\//.test(id))
                        return "ui";
                    return "vendor";
                },
            },
        },
    },
    server: {
        port: 8081,
        strictPort: true,
    },
});
