declare const _default: {
    darkMode: "class";
    content: string[];
    theme: {
        extend: {
            fontFamily: {
                sans: [string, string, string, string];
            };
            colors: {
                ink: string;
                paper: string;
                brand: string;
                saffron: string;
                rosewood: string;
            };
        };
    };
    plugins: never[];
};
export default _default;
